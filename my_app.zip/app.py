# Example Flask app
print('Hello from app.py')